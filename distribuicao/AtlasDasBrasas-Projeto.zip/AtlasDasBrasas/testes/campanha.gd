extends Node

var g
var checks=0
var failures=[]
func check(value,what):
	checks+=1
	if not value:
		failures.append(what)
		push_error(what)

func click(prefix:String):
	for b in g.ui.view.get_children():
		if b is Button and b.text.begins_with(prefix) and not b.disabled:
			b.pressed.emit()
			return
	check(false,"Botão ausente em %s: %s"%[g.ui.mode,prefix])

func walk_to(pos):
	g.hero.position=pos
	if not g.world.interior:g.world.stream(pos)
	Saga.data.pos=[pos.x,pos.y]

func talk(c):
	if not g.world.interior:walk_to(Saga.origin(c)+Vector2(365,268))
	var n=g.world.mentors[0]
	for actor in g.world.mentors:
		if actor.c==c:n=actor;break
	walk_to(n.position+Vector2(0,4))
	g.interact()

func _ready():
	if Saga.exists():
		print("Use XDG_DATA_HOME temporário para preservar o arquivo existente.")
		get_tree().quit(2)
		return
	g=preload("res://cenas/Atlas.tscn").instantiate()
	add_child(g)
	call_deferred("run")

func check_crypt():
	walk_to((Saga.origin(0)+g.world.CRYPT)+Vector2(0,4))
	g.interact()
	click("Examinar o templo")
	check(g.world.room_type=="crypt" and g.world.interior,"Entrada no templo")
	walk_to(Vector2(257,83))
	g.interact()
	check(int(Saga.data.ruins.get("0",0))==0,"Erro rúnico permite recomeçar")
	for spot in [Vector2(68,119),Vector2(258,81),Vector2(431,130)]:
		walk_to(spot)
		g.interact()
	check(int(Saga.data.ruins.get("0",0))==3,"Ordem das três runas")
	var sentinel=g.enemies.front()
	walk_to(sentinel.position+Vector2(-12,0))
	var previous=int(sentinel.hp)
	g.hero.guard=true
	g.hero.facing=Vector2.RIGHT
	var hp=float(Saga.data.hp)
	g.hero.hurt(12,sentinel.position)
	check(hp-Saga.data.hp==3,"Bloqueio direcional")
	g.hero.guard=false
	g.hero.invincible=0
	g.hero.charge=1.1
	g.hero.shoot_arrow()
	for i in 7:await get_tree().physics_frame
	check(sentinel.hp<previous or sentinel.dead,"Colisão da flecha carregada")
	if not sentinel.dead:
		Saga.data.style=2
		g.hero.cooldown=0
		g.hero.attack()
		for i in 12:await get_tree().physics_frame
		check(sentinel.dead or sentinel.hp<previous,"Projétil mágico")
	Saga.data.style=0
	if not sentinel.dead:sentinel.hit(200)
	walk_to(Vector2(425,244))
	g.interact()
	click("Registrar no diário")
	check("0" in Saga.data.relics,"Relicário aberto")
	walk_to(Vector2(256,292))
	g.interact()
	check(not g.world.interior and g.hero.position.distance_to((Saga.origin(0)+g.world.CRYPT))<27,"Retorno pela saída do templo")

func check_guidance():
	var trail=g.world.trail
	trail.follow(Saga.origin(0)+Vector2(440,264),Saga.origin(0)+Vector2(596,264))
	check(trail.available,"Rota até a margem oposta")
	var crossing=false
	var clear_route=true
	for cell in trail.steps:
		var tile=g.world.terrain.get_cell_atlas_coords(cell)
		if tile.x in [11,12] and cell.y-int(Saga.origin(0).y/16) in [8,9,23,24]:crossing=true
		if tile.x in [8,9,10,16]:clear_route=false
	check(crossing and clear_route,"Trilha usa uma ponte transitável")
	var controls=preload("res://interfaces/toque.gd").new()
	controls.game=g
	g.ui.hud.add_child(controls)
	var finger=InputEventScreenTouch.new()
	finger.index=0
	finger.position=controls.STICK+Vector2(41,0)
	finger.pressed=true
	controls._input(finger)
	var attack=InputEventScreenTouch.new()
	attack.index=1
	attack.pressed=true
	attack.position=Vector2(797,480)
	controls._input(attack)
	check(Input.is_action_pressed("right") and Input.is_action_pressed("attack"),"Movimento e ataque com dois dedos")
	attack.pressed=false
	controls._input(attack)
	check(Input.is_action_pressed("right") and not Input.is_action_pressed("attack"),"Soltar ataque conserva o direcional")
	controls.hide()
	check(not Input.is_action_pressed("right"),"Painel oculto solta direcional")
	controls.queue_free()

func check_care_rounds():
	g.ui.journal()
	click("Caderno de rondas")
	check(g.ui.mode=="care_index","Caderno acessível pelo diário")
	for c in Saga.rounds.size():
		var entry=Saga.rounds[c]
		g.ui.care_brief(c)
		click("Marcar rota")
		var target=Saga.origin(c)+g.world.CARE_POINTS[c]
		check(g.route_target()==target,"Orientação até "+entry.place)
		g.world.trail.follow(g.hero.position,target)
		check(g.world.trail.available,"Rota acessível a "+entry.place)
		walk_to(target+Vector2(0,7))
		g.interact()
		click("Examinar o posto")
		check(g.ui.mode=="care_field","Inspeção de "+entry.place)
		if c==5:
			click("Acionar a equipe")
		else:
			click(entry.points[(int(entry.key)+1)%3][0])
			check(not int(entry.key) in g.ui.care_observed,"Exploração livre antes da pista")
			click(entry.points[int(entry.key)][0])
			click("Escolher um cuidado")
		var xp=Saga.data.xp
		click(entry.actions[(int(entry.answer)+1)%3])
		check(g.ui.mode=="care_decision" and Saga.data.xp==xp,"Feedback e nova tentativa")
		click(entry.actions[int(entry.answer)])
		check(g.ui.mode=="care_record" and Saga.data.xp==xp+25 and int(Saga.data.care_route)==-1,"Registro e recompensa de "+entry.place)
		click("Retomar a viagem")
		g.interact()
		click("Refazer a ronda")
		click(entry.points[int(entry.key)][0])
		click("Acionar a equipe" if c==5 else "Escolher um cuidado")
		click(entry.actions[int(entry.answer)])
		check(Saga.data.xp==xp+25,"Revisão sem duplicar a recompensa")
		click("Retomar a viagem")
	check(Saga.restore() and Saga.data.care_records.size()==6,"Seis registros persistentes")
	g.build(true,0,Vector2(365,209))
	g.interact()
	check(g.ui.mode=="care_index","Conversa com Lia na oficina de Junco")

func check_weather():
	var weather=preload("res://scripts/tempo.gd")
	var match_days=true
	for d in 12:
		match_days=match_days and weather.daily_rain(0,d)!=weather.daily_rain(1,d)
	check(match_days,"Viveiros têm acumulados comparáveis e distintos")
	check(weather.period(1439)==3 and weather.period(1440)==0 and weather.day(1440)==1,"Virada do dia")
	g.build(true,0,Vector2(255,190))
	g.ui.journal()
	click("Boletim das margens")
	var before=float(Saga.data.world_minutes)
	g._process(2.0)
	check(Saga.data.world_minutes==before,"Leitura do boletim pausa o relógio")
	click("Aguardar o amanhecer")
	check(Saga.data.world_minutes>before and weather.clock_text(Saga.data.world_minutes)=="06:00","Pouso no interior avança até o amanhecer")
	g.build(false,0,Saga.origin(0)+g.world.WEATHER_BOARD+Vector2.DOWN*8)
	g.ui.play()
	before=Saga.data.world_minutes
	g._process(1.0)
	check(is_equal_approx(Saga.data.world_minutes-before,3.0),"Relógio avança durante exploração")
	g.interact()
	click("Ler o pedido")
	click("Assumir a entrega")
	check(Saga.data.rain_route and g.route_target()==Saga.origin(0)+g.world.GAUGES[0],"Missão inicia no quadro e aponta para o viveiro")
	var day_of_record=int(Saga.data.rain_day)
	for c in [1,0]:
		if c==0:
			Saga.data.world_minutes+=1440
			g.return_title()
			g.continue_game()
			check(int(Saga.data.rain_day)==day_of_record and Saga.data.rain_readings.has("1"),"Salvamento preserva período e leitura parcial")
		var pos=Saga.origin(c)+g.world.GAUGES[c]
		g.world.trail.follow(g.hero.position,pos)
		check(g.world.trail.available,"Trilha até o pluviômetro")
		walk_to(pos+Vector2.DOWN*8)
		g.interact()
		check(g.ui.mode=="gauge","Leitura presencial do instrumento")
		click("Anotar a leitura")
		check(int(Saga.data.rain_readings[str(c)])==weather.daily_rain(c,day_of_record),"Registro do período fixado")
	check(g.route_target()==Saga.origin(0)+g.world.WATER_CART,"As leituras apontam para a carroça")
	walk_to(Saga.origin(0)+g.world.WATER_CART+Vector2.DOWN*9)
	g.interact()
	var dry=0 if int(Saga.data.rain_readings["0"])<int(Saga.data.rain_readings["1"]) else 1
	var xp=Saga.data.xp
	click("Enviar a "+g.ui.LOG_NAMES[1-dry])
	check(int(Saga.data.rain_recipient)==-1 and Saga.data.xp==xp,"Erro explica a comparação e permite corrigir")
	click("Enviar a "+g.ui.LOG_NAMES[dry])
	check(int(Saga.data.rain_recipient)==dry and Saga.data.xp==xp+60 and not Saga.data.rain_route,"Carroça abastece o viveiro escolhido")
	var grown=0
	for plant in g.world.nursery_plants:
		if plant.visible and Saga.region_at(plant.position)==dry:grown+=1
	walk_to(Saga.origin(dry)+g.world.GAUGES[dry]+Vector2.DOWN*8)
	grown=0
	for plant in g.world.nursery_plants:
		if plant.visible and Saga.region_at(plant.position)==dry:grown+=1
	check(grown==3,"O resultado da rega aparece no cenário")
	g.ui.deliver_water(dry)
	check(Saga.data.xp==xp+60,"Reabrir o relatório não duplica a entrega")
	check(Saga.restore() and int(Saga.data.rain_recipient)==dry,"Relatório final e entrega persistem")
	g.ui.play()
	g.ui.open_map()
	click("Previsão da região")
	check(g.ui.mode=="weather","Previsão acessível pelo mapa")

func check_expansion():
	var sectors=preload("res://mapas/setores.gd")
	var field=preload("res://mapas/expedicao.gd")
	var frontier=preload("res://mapas/fronteiras.gd")
	check(sectors.bounds().size==Vector2(9216,4096),"Escala do novo mundo")
	check(sectors.route(sectors.hub(0),sectors.hub(1)).size()==5,"Rede de setores liga Junco a Lume")
	var legacy={"inside":false,"pos":[798.5,180.0],"chapter":2}
	sectors.migrate(legacy,1)
	check(Vector2(legacy.pos[0],legacy.pos[1])==Saga.origin(1)+Vector2(30.5,180.0) and legacy.chapter==2,"Migração preserva posição local e capítulo")
	var old_inside={"inside":true,"pos":[215,252]}
	sectors.migrate(old_inside,1)
	check(old_inside.pos==[215,252],"Migração conserva coordenadas de interiores")
	g.build(false,0,Saga.origin(0)+sectors.CROSSROAD)
	g.ui.play()
	var start_hero=g.hero
	var destination=Saga.origin(1)+sectors.CROSSROAD
	var visited=[]
	for step in 3700:
		g.world.trail.follow(g.hero.position,destination)
		var cell=g.world.current_sector
		if cell not in visited:visited.append(cell)
		if g.hero.position.distance_to(destination)<18:break
		var heading:Vector2=g.hero.position.direction_to(g.world.trail.next_point)
		for direction in [["left",-heading.x],["right",heading.x],["up",-heading.y],["down",heading.y]]:
			if direction[1]>.13:Input.action_press(direction[0],direction[1])
			else:Input.action_release(direction[0])
		await get_tree().physics_frame
	for direction in ["left","right","up","down"]:Input.action_release(direction)
	check(g.region()==1 and g.hero.position.distance_to(destination)<18 and g.hero==start_hero,"Viagem física Junco–Lume com o mesmo aventureiro")
	check(visited.size()>=5 and g.world.loaded.size()<=9 and not g.world.loaded.has(sectors.hub(0)),"Streaming descarta a vila distante após a viagem")
	check(Saga.data.discoveries.has("porto") and Saga.data.discoveries.has("entreposto"),"Descobertas do trajeto")
	g.ui.open_map()
	click("Mapa regional")
	check(g.ui.mode=="regional","Mapa regional aberto pela cartografia")
	g.ui.play()
	var cave_cell=Vector2i(2,3)
	walk_to(sectors.origin(cave_cell)+field.LODGE+Vector2.DOWN*12)
	g.interact()
	check(g.world.room_type=="field_cave" and g.enemies.size()==1,"Gruta opcional e guardião")
	g.return_title()
	g.continue_game()
	check(g.world.room_type=="field_cave" and field.return_cell()==cave_cell,"Salvamento no interior novo")
	if g.enemies.size()==1:g.enemies[0].hit(500)
	walk_to(Vector2(417,106))
	g.interact()
	check(Saga.data.expedition.get("relic_2,3",false),"Relíquia da gruta após o guardião")
	walk_to(field.LODGE_EXIT)
	g.interact()
	check(not g.world.interior and sectors.at(g.hero.position)==cave_cell,"Saída retoma o setor de entrada")
	var bridge_cell=Vector2i(3,1)
	walk_to(sectors.origin(bridge_cell)+Vector2(425,274))
	g.interact()
	check(g.ui.mode=="bridge","Problema de tábuas na rota")
	click("Aplicar a medida")
	check(not Saga.data.expedition.has("bridge"),"Medida errada conserva a passarela fechada")
	for control in g.ui.view.get_children():
		if control is SpinBox:control.value=12
	click("Aplicar a medida")
	var bridge=bridge_cell*Vector2i(48,32)+field.BRIDGE_CELL
	check(Saga.data.expedition.get("bridge",false) and g.world.terrain.get_cell_atlas_coords(bridge).x==12,"A resposta altera a colisão da ponte")
	g.return_title()
	g.continue_game()
	check(sectors.at(g.hero.position)==bridge_cell and g.world.terrain.get_cell_atlas_coords(bridge).x==12,"Posição e ponte restauradas no setor expandido")
	for i in 3:
		walk_to(Saga.origin(frontier.ORIGINS[i])+frontier.GATES[i]+Vector2.DOWN*8)
		g.interact()
		click("Iniciar travessia")
		check(g.world.room_type==frontier.room_for(i),"Fronteira acessível · "+frontier.NAMES[i])
		walk_to(frontier.POSITIONS[i][0]+Vector2.DOWN*8)
		g.interact()
		click("Anotar a pista")
		walk_to(frontier.POSITIONS[i][1]+Vector2.DOWN*8)
		g.interact()
		click(["Nordeste","11 segundos","Leste"][i])
		check(frontier.stage(i)==2,"Mecanismo da fronteira · "+frontier.NAMES[i])
		walk_to(frontier.POSITIONS[i][2]+Vector2.DOWN*8)
		g.interact()
		click("Guardar a carta")
		check(frontier.stage(i)==3,"Carta registrada · "+frontier.NAMES[i])
		if i==0:
			walk_to(frontier.EAST_PIER+Vector2.DOWN*8)
			g.interact()
		walk_to(frontier.EXIT+Vector2.DOWN*6)
		g.interact()
		check(not g.world.interior,"Retorno da fronteira")
	walk_to(Saga.origin(0)+g.world.Obra.POSITION+Vector2.DOWN*8)
	Saga.data.ore=maxi(12,int(Saga.data.ore))
	g.interact()
	click("Erguer abrigo")
	g.interact()
	click("Ampliar")
	g.interact()
	click("Reforjar espada")
	click("Reforjar por")
	check(g.world.Obra.level()==2 and Saga.data.get("ember_sword",false),"Oficina e reforja a partir do cenário")
	g.ui.pause_page()
	click("Bestiário")
	check(g.ui.mode=="bestiario" and Saga.data.fauna.size()>0,"Bestiário registra encontros e fica acessível")

func cross_open_border(first:Vector2i,last:Vector2i):
	var sectors=g.world.Sectors
	var dest=sectors.origin(last)+sectors.CROSSROAD
	var start=sectors.origin(first)+sectors.CROSSROAD
	g.build(false,sectors.realm_at(first),start)
	g.ui.play()
	var traveler=g.hero
	for tick in 1600:
		g.world.trail.follow(g.hero.position,dest)
		if g.hero.position.distance_to(dest)<16:break
		var dir=g.hero.position.direction_to(g.world.trail.next_point)
		for motion in [["left",-dir.x],["right",dir.x],["up",-dir.y],["down",dir.y]]:
			if motion[1]>.13:Input.action_press(motion[0],motion[1])
			else:Input.action_release(motion[0])
		await get_tree().physics_frame
	for action in ["left","right","up","down"]:Input.action_release(action)
	check(g.hero==traveler and sectors.at(g.hero.position)==last and g.hero.position.distance_to(dest)<16,"Travessia a pé entre "+str(first)+" e "+str(last))

func check_territories():
	var sectors=g.world.Sectors
	var field=g.world.Expedition
	var studies=field.Studies
	var names={}
	var edges=[Vector2(8,264),Vector2(760,264),Vector2(328,8),Vector2(328,504)]
	var worst_nodes=0
	for y in 8:
		# A serpentine tour exercises unloading at both ends of the world.
		for idx in 12:
			var cell=Vector2i(idx if y%2==0 else 11-idx,y)
			var realm=sectors.realm_at(cell)
			var area=field.entry(cell)
			if cell==sectors.hub(realm):continue
			check(not area.is_empty() and not names.has(area[2]),"Identidade do setor · "+str(cell))
			names[area[2]]=true
			var base=sectors.origin(cell)
			walk_to(base+sectors.CROSSROAD)
			var nav=g.world.trail
			var start=nav.open_cell(base+sectors.CROSSROAD)
			var reachable=true
			for edge in edges:
				if nav.grid.get_id_path(start,nav.open_cell(base+edge)).is_empty():reachable=false
			check(reachable,"Estradas ligadas às quatro saídas · "+area[0])
			var services=true
			for site in g.world.sites:
				if sectors.at(site.position)!=cell or not site.visible:continue
				var goal=nav.open_cell(site.position+Vector2.DOWN*12)
				if goal.x<0 or nav.grid.get_id_path(start,goal).is_empty() or nav.center(goal).distance_to(site.position)>38:services=false
			check(services and Saga.data.discoveries.has(area[2]),"Acesso aos serviços e descoberta · "+area[0])
			check(g.world.loaded.size()<=9 and g.enemies.size()<=16,"Carga limitada · "+area[0])
			worst_nodes=maxi(worst_nodes,g.world.objects.get_child_count())
			g.world.stream(g.hero.position,false)
		await get_tree().process_frame
	check(names.size()==90,"Noventa setores externos e seis sedes")
	print("Pico no percurso dos setores: ",worst_nodes," objetos de primeiro nível.")
	for realm in range(2,6):
		var case=studies.CASES[realm-2]
		var base=sectors.origin(case.cells[2])
		walk_to(base+studies.DESK+Vector2.DOWN*8)
		g.interact()
		click("Guardar indicação")
		g.ui.journal()
		click("Trabalhos de campo")
		click(["Ocre","Agulha","Nascente","Basalto"][realm-2])
		click("Guiar até o posto")
		check(g.route_target()==sectors.origin(case.cells[0])+studies.DESK,"Guia ao primeiro registro · "+case.title)
		for slot in [1,0]:
			walk_to(sectors.origin(case.cells[slot])+studies.DESK+Vector2.DOWN*8)
			g.interact()
			click("Anotar no diário")
			check(studies.noted(realm,slot),"Registro de campo · "+case.sites[slot])
		g.return_title()
		g.continue_game()
		check(studies.noted(realm,0) and studies.noted(realm,1),"Registros restaurados · "+case.title)
		check(g.route_target()==base+studies.DESK,"Guia avança até o posto de aplicação")
		walk_to(base+studies.DESK+Vector2.DOWN*8)
		g.interact()
		check(g.ui.mode=="field_work","Bancada da expedição · "+case.title)
		match realm:
			2,4:click(case.choices[1-case.correct])
			3:click("Registrar cota")
			5:click("Testar comando")
		check(not studies.solved(realm) and g.ui.mode=="field_work","Erro permite corrigir · "+case.title)
		var showed_hint=false
		for item in g.ui.view.get_children():
			if item is Label and item.text==case.hint:showed_hint=true
		check(showed_hint,"Devolutiva específica · "+case.title)
		match realm:
			2,4:click(case.choices[case.correct])
			3:
				for press in 9:click("+20 m")
				click("Registrar cota")
			5:
				for control in g.ui.view.get_children():
					if control is Button and control.toggle_mode:control.button_pressed=true
				click("Testar comando")
		check(studies.solved(realm),"Mudança regional concluída · "+case.title)
		check(g.map_waypoint().x<0,"Guia devolve o controle ao objetivo da campanha")
		click("Voltar à estrada")
		g.return_title()
		g.continue_game()
		var xp=Saga.data.xp
		g.interact()
		click("Voltar à estrada")
		check(studies.solved(realm) and Saga.data.xp==xp,"Conclusão persistente sem prêmio duplicado · "+case.title)
		match realm:
			2:
				walk_to(base+studies.RESULTS+Vector2.DOWN*8)
				g.interact()
				check(Saga.data.expedition.get("marker_10,1",false),"Marco dos Oleiros utilizável")
				g.ui.play()
			3:
				var crossing=case.cells[2]*Vector2i(48,32)+Vector2i(34,8)
				check(g.world.terrain.get_cell_atlas_coords(crossing).x==12 and not g.world.trail.grid.is_point_solid(crossing),"Passarela alta transitável")
			4:
				walk_to(sectors.origin(case.cells[1])+studies.RESULTS+Vector2.DOWN*8)
				var herbs=Saga.data.herbs
				g.interact()
				g.interact()
				check(Saga.data.herbs==herbs+4,"Colheita na margem restaurada paga uma vez")
			5:
				walk_to(base+studies.RESULTS+Vector2.DOWN*8)
				g.interact()
				check(g.world.room_type=="field_vault","Entrada ao depósito liberado")
				walk_to(Vector2(367,191))
				g.interact()
				click("Guardar o torque")
				g.ui.bag()
				click("Acessórios")
				click("Torque de cobre")
				check(Saga.data.charm=="Torque de cobre" and Saga.power()==12+2*Saga.level(),"Torque equipado pela mochila")
				g.ui.play()
				walk_to(field.LODGE_EXIT)
				g.interact()
	for service_cell in [Vector2i(5,2),Vector2i(8,1),Vector2i(8,6),Vector2i(4,4),Vector2i(1,6)]:
		walk_to(sectors.origin(service_cell)+field.Guilds.DOOR+Vector2.DOWN*10)
		g.interact()
		check(g.world.room_type=="field_service","Casa de ofício acessível · "+str(service_cell))
		walk_to(field.Guilds.BENCH)
		g.interact()
		var service=field.Guilds.SERVICES[field.entry(service_cell)[2]][2]
		click({"reading":"Consultar enciclopédia","care":"Consultar rondas","craft":"Trabalhar na bancada"}[service])
		check(g.ui.mode in ["codex","care","care_index","bag"],"Serviço local abre sua interface · "+g.ui.mode)
		g.ui.play()
		walk_to(field.LODGE_EXIT)
		g.interact()
		check(sectors.at(g.hero.position)==service_cell,"Casa de ofício devolve à rua correta")
	var chambers=field.Chambers
	for room_cell in [Vector2i(10,2),Vector2i(10,6),Vector2i(7,4),Vector2i(3,6)]:
		walk_to(sectors.origin(room_cell)+field.LODGE+Vector2.DOWN*10)
		g.interact()
		walk_to(chambers.PANEL)
		g.interact()
		check(g.world.room_type=="field_cave","Parede oculta antes da pista")
		walk_to(Vector2(213,112))
		g.interact()
		click("Examinar a parede")
		walk_to(chambers.PANEL)
		g.interact()
		check(g.world.room_type=="field_chamber" and g.enemies.size()==1,"Câmara secreta com sentinela · "+str(room_cell))
		g.return_title()
		g.continue_game()
		check(g.world.room_type=="field_chamber" and field.return_cell()==room_cell,"Salvamento dentro da câmara")
		if g.enemies.size()==1:g.enemies[0].hit(500)
		walk_to(chambers.KEEPER)
		var witness=g.world.nearest(g.hero.position)
		check(witness!=null and witness.art.texture!=null,"Testemunha visível na câmara")
		g.interact()
		click("Receber")
		var i=chambers.index_for(field.entry(room_cell))
		check(Saga.data.expedition.get("archive_"+chambers.KEYS[i],false),"Relíquia da testemunha · "+chambers.ITEMS[i])
		walk_to(field.LODGE_EXIT)
		g.interact()
		check(g.world.room_type=="field_cave","Retorno à galeria de origem")
		walk_to(field.LODGE_EXIT)
		g.interact()
		check(not g.world.interior and sectors.at(g.hero.position)==room_cell,"Retorno à entrada externa original")
	for realm in range(2,6):
		var cell=field.Caravan.today(realm)
		var place=sectors.origin(cell)+field.Caravan.Dock
		walk_to(place)
		g.interact()
		click("Aceitar a carta")
		Saga.data.world_minutes+=1440
		g.world.update_caravans(field.Weather.day(Saga.data.world_minutes))
		check(g.world.nearest(place)==null or g.world.nearest(place).tag!="field_caravan","Caravana muda de parada no outro dia")
		walk_to(sectors.origin(field.Caravan.Recipients[realm-2])+studies.DESK)
		g.interact()
		click("Entregar a carta")
		check(Saga.data.expedition.get("letter_"+str(realm),0)==2,"Carta entregue a outro reino")
	var lava_cell=Vector2i(2,6)
	var lava
	walk_to(sectors.origin(lava_cell)+sectors.CROSSROAD)
	for p in g.world.terrain.get_used_cells_by_id(2):
		if sectors.at(g.world.trail.center(p))==lava_cell:
			lava=p
			break
	check(lava!=null,"Rio de lava com colisão própria")
	if lava!=null:
		var blocked=g.world.trail.center(lava)
		walk_to(blocked)
		g.return_title()
		g.continue_game()
		check(g.hero.position!=blocked and sectors.at(g.hero.position)==lava_cell and g.world.trail.can_stand(g.hero.position),"Recuperação de posição antiga sobre terreno novo")
	for pair in [[Vector2i(7,1),Vector2i(8,1)],[Vector2i(9,3),Vector2i(9,4)],[Vector2i(8,6),Vector2i(7,6)],[Vector2i(4,6),Vector2i(3,6)]]:
		await cross_open_border(pair[0],pair[1])
	check(Saga.data.learned.size()==29 and Saga.data.won and Saga.data.chapter==6,"Trabalhos de campo preservam o fim da campanha")

func run():
	await get_tree().process_frame
	check(g.ui.mode=="menu","Menu inicial")
	click("Iniciar jornada")
	click("Descer até a margem")
	click("Voltar à aventura")
	check(g.enemies.size()<15 and g.world.loaded.size()==9,"Somente setores próximos ativos")
	check_guidance()
	var start=g.hero.position
	Input.action_press("right")
	for i in 12:await get_tree().physics_frame
	Input.action_release("right")
	check(g.hero.position.x>start.x+8,"Movimento com entrada física")
	walk_to(Saga.origin(0)+g.world.HOME+Vector2(0,10))
	g.interact()
	check(g.world.interior and g.region()==0,"Entrada na oficina")
	walk_to(Vector2(255,290))
	g.interact()
	check(not g.world.interior,"Saída da oficina")
	await check_crypt()
	var menu_label=g.ui.label(g.ui.hud,"Texto curto",10,10,200,24,14)
	check(menu_label.size.y<=25,"Altura do texto após quebra automática")
	menu_label.queue_free()
	var bridge=Vector2i(Saga.origin(0)/16)+Vector2i(g.world.channel_x(0,16)+1,16)
	check(g.world.terrain.get_cell_atlas_coords(bridge).x==8,"Travessia principal fechada no início")
	check(not g.can_travel(),"Restrições de deslocamento antes da aliança")
	walk_to(Saga.origin(0)+g.world.ARCH+Vector2(0,5))
	check(g.can_travel(),"Viagem liberada no marco")
	var citizen=g.world.residents[0]
	walk_to(citizen.position+Vector2(0,4))
	g.interact()
	check(g.ui.mode=="dialog","Conversa com morador")
	click("Até breve")
	for c in 6:
		talk(c)
		click("Abrir o arquivo" if c%2==0 else "Confiar no conselho")
		click("Ouvir o ensinamento")
		click("Anotar e explorar")
		check(Saga.data.taught==0,"Briefing do capítulo %d"%c)
		for stage in Saga.chapter_lessons(c).size():
			var l=Saga.current_lesson()
			if stage>0:
				talk(c)
				click("Estudar a tarefa")
				click("Anotar e explorar")
			walk_to(Saga.origin(c)+g.world.POINTS[stage%3]+Vector2(0,6))
			g.interact()
			check(g.ui.mode=="challenge","Atividade aberta: "+l.title)
			var count=Saga.data.learned.size()
			match l.type:
				"dial":
					g.ui.evaluate(int(l.answer)+1)
					check(g.ui.response.text!="" and count==Saga.data.learned.size(),"Feedback numérico")
					g.ui.adjust(int(l.answer))
					click("Aplicar medida")
				"grid":
					click("A1")
					check(g.ui.response.text!="","Feedback cartográfico")
					click(l.answer)
				"pick":
					click(l.opts[(int(l.answer)+1)%3])
					check(g.ui.response.text!="","Feedback contextual")
					click(l.opts[int(l.answer)])
				"order":
					for j in [2,1,0]:click(l.opts[j])
					check(g.ui.response.text!="" and g.ui.steps.is_empty(),"Reinício da sequência")
					for j in l.answer:click(l.opts[int(j)])
				"write":
					g.ui.writing.text="Guardem o mapa na biblioteca porque o rio voltou a subir."
					click("Revisar meu aviso")
					for node in g.ui.view.get_children():
						if node is CheckBox:node.button_pressed=true
					click("Afixar aviso")
			check(Saga.data.learned.size()==count+1,"Registro da atividade "+l.title)
			click("Voltar à aventura")
		talk(c)
		click("Pedido local")
		click("Aceitar pedido")
		if c in [2,5]:
			for e in g.enemies.duplicate():
				if e.quest_id=="side"+str(c):e.hit(500)
		if c==4:
			g.ui.bag()
			click("Preparar poção")
			click("Voltar à aventura")
		else:
			walk_to(Saga.origin(c)+g.world.CACHE)
			g.interact()
		talk(c)
		click("Pedido local")
		click("Guardar o presente")
		check(int(Saga.data.side.get(str(c),0))==2,"Missão secundária "+str(c))
		walk_to(Saga.origin(c)+g.world.POINTS[2]+Vector2(0,5))
		g.interact()
		var guardian=null
		for e in g.enemies:
			if e.boss:guardian=e
		check(guardian!=null,"Guardião do capítulo")
		if guardian:
			walk_to(guardian.position-Vector2(10,0))
			g.hero.facing=Vector2.RIGHT
			for i in 20:
				if not is_instance_valid(guardian) or guardian.dead:break
				g.hero.attack()
			check(Saga.data.chapter==c+1,"Recompensa após o combate")
			click("Continuar a jornada")
			if c==0:check(g.world.terrain.get_cell_atlas_coords(bridge).x==12,"Travessia reconstruída")
			if c==1:check(g.can_travel(),"Aliança libera viagem fora do marco")
		await get_tree().process_frame
	check(Saga.data.learned.size()==29,"29 atividades concluídas")
	g.ui.book_ch=0
	g.ui.codex()
	click("Tábuas por vão")
	click("Voltar à prática")
	g.ui.adjust(7)
	click("Aplicar medida")
	check(int(Saga.data.review.get("Tábuas por vão",0))==1 and Saga.data.learned.size()==29,"Revisão sem duplicar progresso")
	click("Voltar à enciclopédia")
	click("Voltar à aventura")
	g.ui.skills()
	click("Passo leve")
	check(Saga.has_skill(0),"Treino de habilidade")
	click("Voltar à aventura")
	walk_to(Saga.origin(5)+g.world.ARCH+Vector2(0,7))
	g.interact()
	click("Enfrentar Aster")
	check(g.region()==6 and g.enemies.size()==1,"Entrada na caldeira")
	var boss=g.enemies.front()
	var health=boss.hp
	boss.hit(200)
	check(boss.hp==health,"Escudo fechado bloqueia dano")
	Saga.data.style=2
	Saga.data.mp=Saga.max_mp()
	Input.action_press("attack")
	for i in 900:
		await get_tree().physics_frame
		if Saga.data.won:break
	Input.action_release("attack")
	check(Saga.data.won,"Abertura do escudo e vitória")
	click("Escrever o último registro")
	click("Voltar ao mundo aberto")
	g.return_title()
	# Simulate an interrupted primary file and exercise the previous atomic copy.
	var damaged=FileAccess.open(Saga.SAVE,FileAccess.WRITE)
	damaged.store_string("{}")
	damaged.close()
	g.continue_game()
	check(Saga.data.won and Saga.data.chapter==6 and Saga.data.learned.size()==29 and Saga.has_skill(0),"Carregar campanha concluída")
	check(Saga.data.letter!="","Texto autoral persistido")
	check_care_rounds()
	check_weather()
	await check_expansion()
	g.ui.play()
	await check_territories()
	print("ATLAS: %d verificações; %d falhas."%[checks,failures.size()])
	get_tree().quit(0 if failures.is_empty() else 1)

